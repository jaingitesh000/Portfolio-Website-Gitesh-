# Gitesh Jain — Portfolio

A single-page site (`index.html`) with client-side view routing between the
homepage and the Quest+ case study. Styled with a locally-compiled Tailwind
CSS build (no CDN script, no runtime JIT compilation in the browser).

## Structure
- `index.html` — all markup for both views (Home + Quest+ case study)
- `src/input.css` — Tailwind entry file (directives + small custom rules)
- `tailwind.config.js` — design tokens (colors, fonts) matching the site
- `styles.css` — the compiled, minified stylesheet `index.html` links to

## Rebuilding the CSS
Whenever you add or change class names in `index.html`, rebuild the stylesheet:

```bash
npm install
npm run build     # one-off minified build
npm run watch      # rebuilds on every save while you edit
```

## Opening the site
Just open `index.html` in a browser — no server required.
