/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./*.html"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        "surface": "#FAF9F6",
        "surface-dim": "#F3F2ED",
        "surface-card": "#FFFFFF",
        "ink": "#111111",
        "ink-muted": "#686866",
        "ink-subtle": "#8E8E8A",
        "line-subtle": "#E5E5DF",
        "line-strong": "#CFCFC8",
        "brand-accent": "#E63C1E",
        "brand-violet": "#C084FC"
      },
      fontFamily: {
        display: ['"Hanken Grotesk"', '"Space Grotesk"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
        sans: ['Inter', 'sans-serif']
      }
    }
  },
  plugins: [
    require("@tailwindcss/forms"),
    require("@tailwindcss/container-queries")
  ]
}
